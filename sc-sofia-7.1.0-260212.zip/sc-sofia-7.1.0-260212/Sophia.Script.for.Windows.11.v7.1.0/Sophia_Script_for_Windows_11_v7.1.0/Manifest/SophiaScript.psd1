﻿@{
	RootModule            = '..\Module\Sophia.psm1'
	ModuleVersion         = '7.1.0'
	GUID                  = '109cc881-c42b-45af-a74a-550781989d6a'
	Author                = 'Team Sophia'
	Copyright             = '(c) 2014—2026 Team Sophia. All rights reserved'
	Description           = 'Module for Windows fine-tuning and automating the routine tasks'
	PowerShellVersion     = '5.1'
	ProcessorArchitecture = 'AMD64'
	FunctionsToExport     = '*'

	PrivateData = @{
		PSData = @{
			LicenseUri    = 'https://github.com/farag2/Sophia-Script-for-Windows/blob/master/LICENSE'
			ProjectUri    = 'https://github.com/farag2/Sophia-Script-for-Windows'
			IconUri       = 'https://raw.githubusercontent.com/farag2/Sophia-Script-for-Windows/master/img/Sophia.png'
			ReleaseNotes  = 'https://github.com/farag2/Sophia-Script-for-Windows/blob/master/CHANGELOG.md'
		}
	}
}
